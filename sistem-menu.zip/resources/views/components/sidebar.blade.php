<div class="bg-primary text-white p-3 w-25 min-vh-100">
  <h4>Admin Dashboard</h4>
  <ul class="nav flex-column mt-3">
    <li class="nav-item">
      <a href="/dashboard" class="nav-link text-white">Dashboard</a>
    </li>
    <li class="nav-item">
      <a href="/users" class="nav-link text-white">Manage Users</a>
    </li>
    <li class="nav-item">
      <a href="/reports" class="nav-link text-white">Reports</a>
    </li>
  </ul>
</div>